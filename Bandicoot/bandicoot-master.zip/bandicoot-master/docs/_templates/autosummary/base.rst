{% extends "!autosummary/base.rst" %}
{% set fullname = objname %}