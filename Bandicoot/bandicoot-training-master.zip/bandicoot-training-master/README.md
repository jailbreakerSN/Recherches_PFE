

## Training materials for bandicoot [![Binder](http://mybinder.org/badge.svg)](http://mybinder.org/repo/cynddl/bandicoot-training)

This repository contains notebooks for users willing to discover bandicoot.
They can be used locally with [Jupyter Notebook](http://jupyter.org/) or online with [Binder](http://mybinder.org/).
